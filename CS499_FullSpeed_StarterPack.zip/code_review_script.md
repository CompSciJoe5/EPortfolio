# Code Review Script (8–10 min)

Intro → Existing → Analysis → Enhancements → Wrap‑up.

Key points: Travlr SPA; gaps (validation, RBAC, naive filtering, tests); planned fixes; outcomes mapping.
