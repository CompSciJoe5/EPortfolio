import mongoose from 'mongoose'
const TripSchema=new mongoose.Schema({title:{type:String,required:true,trim:true,maxlength:120},destination:{type:String,required:true,index:true},price:{type:Number,required:true,min:0},startDate:{type:Date,required:true},endDate:{type:Date,required:true}},{timestamps:true});TripSchema.index({price:1});export default mongoose.model('Trip',TripSchema)
