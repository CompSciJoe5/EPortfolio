import { Router } from 'express'
import jwt from 'jsonwebtoken'
import bcrypt from 'bcryptjs'
import User from '../models/User.js'
const r=Router()
r.post('/login', async (req,res)=>{const {email,password}=req.body;const u=await User.findOne({email});if(!u)return res.status(401).json({error:'Invalid credentials'});const ok=await bcrypt.compare(password,u.passwordHash);if(!ok)return res.status(401).json({error:'Invalid credentials'});const token=jwt.sign({id:u._id,role:u.role},process.env.JWT_SECRET||'changeme',{expiresIn:'2h'});res.json({token})})
export default r
