import { Router } from 'express'
import Trip from '../models/Trip.js'
import { authorize } from '../middleware/authorize.js'
const r=Router()
r.get('/', async (req,res)=>{const {dest,min=0,max=10000,sort='priceAsc'}=req.query;const q={price:{$gte:Number(min),$lte:Number(max)}};if(dest) q.destination=dest;const sortMap={priceAsc:{price:1},priceDesc:{price:-1},startDate:{startDate:1}};const items=await Trip.find(q).sort(sortMap[sort]||{}).limit(200);res.json(items)})
r.post('/', authorize('admin'), async (req,res)=>{try{const t=await Trip.create(req.body);res.status(201).json(t)}catch(e){res.status(400).json({error:e.message})}})
export default r
